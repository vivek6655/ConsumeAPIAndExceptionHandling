package com.example.demo.consumeAPI;

public class Solar {
	
	private int id;
	private String name;
	private int age;
	private String about;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public String getAbout() {
		return about;
	}
	public void setAbout(String about) {
		this.about = about;
	}
	public Solar(int id, String name, int age, String about) {
		super();
		this.id = id;
		this.name = name;
		this.age = age;
		this.about = about;
	}
	public Solar() {
		super();
	}
	
	

}
