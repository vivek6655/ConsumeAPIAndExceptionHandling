package com.example.demo.exception2;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class MyController {
	
	private Logger LOGGER=LoggerFactory.getLogger(getClass());
	
	   @RequestMapping(value = {"/batteryData"}, method = {RequestMethod.GET})
	   public BatteryResponseDTO getBatteryDataByOmc(@RequestParam int omcid) {
	      BatteryResponseDTO batteryResponseDTO = new BatteryResponseDTO();
	      
	      try {
	       LOGGER.info("In UserController for checkUser Request");
	       BatteryResponseDTO batteryResponseDto = null;
	         return batteryResponseDto;
	      } catch (BaseException exception) {
	       LOGGER.warn("Exception occur during = " + exception.getMessage());
	        batteryResponseDTO.setErrorCode(Integer.valueOf(ErrorCodes.GENERAL_ERROR.getCode()));
	        batteryResponseDTO.setStatus(Integer.valueOf(HttpStatus.INTERNAL_SERVER_ERROR.value()));
	        batteryResponseDTO.setErrorMessage(exception.getCause().getMessage());
	       ResponseEntity<BatteryResponseDTO> responseEntity = new ResponseEntity(batteryResponseDTO, 
	            HttpStatus.INTERNAL_SERVER_ERROR);
	       
	     }
	      catch (RuntimeException exception) {
	        LOGGER.warn("Error occurred during runtime creating user", exception);
	    } catch (Exception exception) {
	        LOGGER.warn("Error occurred while creating user", 
	            exception);
	      } 
	     return null;
	    }

}
