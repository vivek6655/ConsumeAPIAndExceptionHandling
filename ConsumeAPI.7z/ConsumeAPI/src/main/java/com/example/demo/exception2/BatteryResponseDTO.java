package com.example.demo.exception2;

public class BatteryResponseDTO extends AbstractResponseDTO {

}
