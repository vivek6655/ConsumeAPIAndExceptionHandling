package com.example.demo.exception;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;

@ResponseStatus(code=HttpStatus.NOT_FOUND)
public class CloudVendorNotFoundException extends RuntimeException{

	
	CloudVendorNotFoundException(String msg){
		super(msg);
	}

	CloudVendorNotFoundException(String msg,Throwable cause){
		super(msg,cause);
	}
	
	
}
