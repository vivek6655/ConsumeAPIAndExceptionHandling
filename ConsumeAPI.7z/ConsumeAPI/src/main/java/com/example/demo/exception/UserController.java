package com.example.demo.exception;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;


@RestController
public class UserController {
	
	@GetMapping("/")
	public ResponseEntity<User> getUser() throws Exception{
	
		User user=new User();
		if(user==null) {
			 throw new UserNotFoundException("user not find yet");
		}
		return null;	
	}

}
