package com.example.demo.exception2;

public enum ErrorCodes {

	 USER_NOT_FOUND(1001),
	 GENERAL_ERROR(5000);
	
	private final int errorCode;
	
	   ErrorCodes(int errorCode) {
	    this.errorCode = errorCode;
		   }
	   
	      public int getCode() {
		    return this.errorCode;
		    }
}
