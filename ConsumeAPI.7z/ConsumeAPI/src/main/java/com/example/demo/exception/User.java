package com.example.demo.exception;

import java.io.Serializable;

import org.springframework.stereotype.Component;

@Component
public class User implements Serializable {

	private Integer id;
	private String employee_name;
	
	
	public User() {
	
	}
	public User(Integer id, String employee_name) {
		super();
		this.id = id;
		this.employee_name = employee_name;
	}
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getEmployee_name() {
		return employee_name;
	}
	public void setEmployee_name(String employee_name) {
		this.employee_name = employee_name;
	}
	
	@Override
	public String toString() {
		return "User [id=" + id + ", employee_name=" + employee_name + "]";
	}
	
	
	
	
}
