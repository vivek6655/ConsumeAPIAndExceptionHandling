package com.example.demo.exception2;

public class BaseException extends RuntimeException{
	
	  private String errorMsg;
	  private ErrorCodes errorCode;
	  private String ErrorValue;
	  
	  

   public BaseException(String errorMsg, ErrorCodes errorCode) {
     super(errorMsg);
     this.errorMsg = errorMsg;
    this.errorCode = errorCode;
   }
   
   
   public BaseException(String errorMsg, ErrorCodes errorCode, String errorValue) {
	       super(errorMsg);
	        this.errorMsg = errorMsg;
	        this.errorCode = errorCode;
	        this.ErrorValue = errorValue;
	   }

       public BaseException(String message) {
	       super(message);
	        this.errorMsg = message;
	   }


	public String getErrorMsg() {
		return errorMsg;
	}


	public void setErrorMsg(String errorMsg) {
		this.errorMsg = errorMsg;
	}


	public ErrorCodes getErrorCode() {
		return errorCode;
	}


	public void setErrorCode(ErrorCodes errorCode) {
		this.errorCode = errorCode;
	}


	public String getErrorValue() {
		return ErrorValue;
	}


	public void setErrorValue(String errorValue) {
		ErrorValue = errorValue;
	}
       
       
}
