package com.example.demo.consumeAPI;


import java.math.BigDecimal;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

@RestController
public class ConsumeAPIController {

	@Autowired
	private RestTemplate restTemplate;
	
	String baseUrl="https://jsonplaceholder.typicode.com/";
	
	
	String GETAPI="posts";
	String POSTBYID="posts/";
	String 	DELETE_BYID="posts/";
	String POST_URL="https://jsonplaceholder.typicode.com/posts";
	String POST_URL_BYID="https://jsonplaceholder.typicode.com/posts/";
	
	StringBuilder sb=new StringBuilder();
	
	@GetMapping("/result")
	public List<Map<String,Object>> getPosts(){
		String url=sb.append(baseUrl).append(GETAPI).toString();
		HttpEntity<HttpHeaders> httpEntity=new HttpEntity<>(getHttpHeaders());
		var res=restTemplate.exchange(url, HttpMethod.GET, httpEntity, List.class);
		return res.getBody();
	}

	@GetMapping("/result/{id}")
	public Map<String,Object> getPostsById(@PathVariable int id){
		String url=sb.append(POSTBYID).append(id).toString();
		HttpEntity<HttpHeaders> httpEntity=new HttpEntity<>(getHttpHeaders());
		var res=restTemplate.exchange(url, HttpMethod.GET, httpEntity, Map.class);
		return res.getBody();
		
	}
	
	
	@PostMapping("/create-post")
	public Map<String,Object> createPost(@RequestBody Map<String ,Object> payload){
		HttpEntity<Map> httpEntity=new HttpEntity<>(payload,getHttpHeaders());
		var res=restTemplate.exchange(POST_URL, HttpMethod.POST, httpEntity, Map.class);
		return res.getBody();
		
	}
	
	@PostMapping("/update-post/{id}")
	public Map<String,Object> createPost(@RequestBody Map<String ,Object> payload,@PathVariable int id){
		String url=sb.append(POSTBYID).append(id).toString();
		HttpEntity<Map> httpEntity=new HttpEntity<>(payload,getHttpHeaders());
		var res=restTemplate.exchange(url, HttpMethod.PUT, httpEntity, Map.class);
		return res.getBody();
		
	}
	
	@DeleteMapping("/pooja/{id}")
	public List<Map<String,Object>> getPosts(@PathVariable int id){
		String url=sb.append(baseUrl).append(DELETE_BYID).append(id).toString();
		HttpEntity<HttpHeaders> httpEntity=new HttpEntity<>(getHttpHeaders());
		var res=restTemplate.exchange(url, HttpMethod.DELETE, httpEntity, List.class);
		return res.getBody();
		
	}
	
	
	private HttpHeaders getHttpHeaders() {
		HttpHeaders header=new HttpHeaders();
		header.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
		header.setContentType(MediaType.APPLICATION_JSON);
		return header;
	}
	
	@GetMapping("/")
	public ResponseEntity<String> getResult() {
		return restTemplate.getForEntity(baseUrl, String.class); 
	}
	
	@GetMapping("/sole")
	public Solar getResult1() {
		var s= restTemplate.getForEntity(baseUrl, Solar.class);
		Solar solar=s.getBody();
		s.getStatusCode();
		s.getHeaders();
		return new Solar(solar.getId(),solar.getName(),solar.getAge(),solar.getAbout());
	}
	
	
	@GetMapping("/currency-conversion/from/{from}/to/{to}/quantity/{quantity}")
	public CurrencyConversion calculateCurrencyConversion(
			@PathVariable String from,
			@PathVariable String to,
			@PathVariable BigDecimal quantity
			) {
		
		 HashMap<String, String> uriVariables=new HashMap();
		 uriVariables.put("from", from);
		 uriVariables.put("to", to);
		 
		ResponseEntity<CurrencyConversion> responseEntity=new RestTemplate().getForEntity
		("http://localhost:8000/currency-exchange/from/{from}/to/{to}",
				CurrencyConversion.class,uriVariables);
		
		CurrencyConversion currencyConversion=responseEntity.getBody();
		return new CurrencyConversion
				(
						currencyConversion.getId(),
						from,to,quantity,
						currencyConversion.getConversionMultiple(),
						quantity.multiply(currencyConversion.getConversionMultiple())
						,currencyConversion.getEnvironment());
		
	}
}
