package com.example.demo.exception;

import java.time.LocalDate;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

@ControllerAdvice
public class CustomizedException extends ResponseEntityExceptionHandler{
	
	@ExceptionHandler(Exception.class)
	public final ResponseEntity<ErrorDetails> handleExceptions(Exception ex, WebRequest request) throws Exception {
		ErrorDetails errorDetails=new ErrorDetails(LocalDate.now(),ex.getMessage(),request.getDescription(false));
		return new ResponseEntity<ErrorDetails>(errorDetails,HttpStatus.INTERNAL_SERVER_ERROR);
	}
	
	@ExceptionHandler(UserNotFoundException.class)
	public final ResponseEntity<ErrorDetails> userNotFoundException(Exception ex, WebRequest request) throws Exception {
		ErrorDetails errorDetails=new ErrorDetails(LocalDate.now(),ex.getMessage(),request.getDescription(false));
		return new ResponseEntity<ErrorDetails>(errorDetails,HttpStatus.NOT_FOUND);
	}
	
	@ExceptionHandler(GeneralException.class)
	public final ResponseEntity<ErrorDetails> generalException(Exception ex, WebRequest request) throws Exception {
		ErrorDetails errorDetails=new ErrorDetails(LocalDate.now(),ex.getMessage(),request.getDescription(false));
		return new ResponseEntity<ErrorDetails>(errorDetails,null, Integer.valueOf(HttpStatus.INTERNAL_SERVER_ERROR.value()));
	}
	

	@ExceptionHandler(CloudVendorNotFoundException.class)
	public final ResponseEntity<CloudVendorException> handleCloudVendorException(CloudVendorNotFoundException cloudVendorNotFoundException) throws Exception {
		CloudVendorException cloudVendorExc=new CloudVendorException(
				cloudVendorNotFoundException.getMessage(),
				cloudVendorNotFoundException.getCause(),
				HttpStatus.NOT_FOUND
				);
		return new ResponseEntity<CloudVendorException>(cloudVendorExc,HttpStatus.NOT_FOUND);
       }
}
